//FORMA ACOTADA DE ESCRIBIR LA FUNCION .ready()
var modalRegInputs 

$(function(){
	// AL ABRIR EL MODAL DE REGISTRO
	$('#RegistrarseModal').on('show.bs.modal', function() {
		modalRegInputs = $('#RegFormUsuario :input');
		console.log(modalRegInputs);
	});

	// AL CERRAR MODAL DE REGISTRO
	$('#RegistrarseModal').on('hidden.bs.modal', function() {
		modalRegBorrar();
	});

	// AL CLICK EN EL BOTON DE SIGUIENTE/REGISTRAR
    $("#RegFormBotonAceptar").on('click', function(){
        if ( $("#RegFormBotonAceptar").text()=="Siguiente") {
			var ok=true;
			console.log(ok);
			ok= (ok && RegFormValidateEmail());
			console.log(ok);
			ok= (ok && RegFormValidatePasswords());
			console.log(ok);
			if (ok) {
				RegFormAPag(2);
				$("#RegFormBotonAceptar").text("Registrarse");
			} else {
				RegFormAPag(1);
				return;
			}
		} else {
			if (RegFormValidate()) {
				RegFormRegistrarUsuario()
			} else {
				cerrarModales();
			}
		}
	} );

	$("#RegFormPassword2").on("focusout", function(){
		RegFormValidatePasswords();

	})

	$("#RegFormEmail").on("focusout", function(){
		RegFormValidateEmail();
	})


});

$('.popover-dismiss').popover({
	trigger: 'focus'
})


function RegFormValidate(){
	return
}

function RegFormValidatePasswords(){
	if (modalRegInputs[1].value != modalRegInputs[2].value)
		{RegFormMensaje("Las contraseñas no coinciden");
		console.log("pw con error");
		RegFormAPag(1);
		return false
	}
	if (modalRegInputs[1].value <4 )
		{RegFormMensaje("La contraseña tiene que tener más de 4 caracteres");
		console.log("pw con error");
		RegFormAPag(1);
		return false
	}
	modalRegInputs[1].value
	console.log("pw sin error");
	return true;
}

function RegFormValidateEmail(){
	if ((modalRegInputs[0].validationMessage=="")&&(modalRegInputs[0].value!="")) {
		console.log("email sin error");
		return true;
	} else {
		RegFormMensaje("El email no es válido");
		console.log("email con error");
		RegFormAPag(1);
		return false;
	}
}
function modalRegBorrar(){
	for (const iterator of modalRegInputs) {
		iterator.value="";
	}
	$("#RegFormBotonAceptar").text("Siguiente");
	RegFormAPag(1);
}

function RegFormMensaje(msg) {
	$("#labelModalRegMensaje").slideUp(1000, ()=> {
		$("#labelModalRegMensaje").text(msg);
		$("#labelModalRegMensaje").slideDown(1000)
	})
} 
function RegFormAPag(num){
	$(`#modalRegTab li:nth-child(${num}) a`).tab('show');
}