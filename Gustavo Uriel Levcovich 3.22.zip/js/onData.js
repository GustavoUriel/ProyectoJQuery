function RegFormRegistrarUsuario(){
	let inputs = $('#RegFormUsuario :input');
	if (inputs[0].value=="q")
		{return ""}
	else{
		return "nonono";
	}
}


