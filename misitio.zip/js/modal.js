$(document).ready(function(){
        $("#carouselOtorgantes").carousel({  
        interval: 100 
    });

})
/* let botonLogIn = document.getElementById("LogInButton");
botonLogIn.addEventListener("click",clickLogIn);
function clickLogIn (){
    let     temp=document.getElementById("LogInModal");
    temp.modal('show');
}

let botonRegistrarse = document.getElementById("RegistrarseButton");
botonLogIn.addEventListener("click",clickLogIn);
function clickLogIn (){
    let     temp=document.getElementById("RegistrarseModal");
    temp.modal('show');
} */

/* $("#RegistrarseButton").click(function(){
    $("#RegistrarseModal").modal('show');
    }); */
    $( "#RegistrarseButton" ).click(function() {
        alert( "Handler for .click() called." );
      });
$("#LogInButton").click(function(){
    $("#LogInModal").modal('show');
});

